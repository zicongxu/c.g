---
name: film-screenplay
description: Deeply merge and format user-approved story materials into a director-ready screenplay, or revise an existing screenplay, when the router selects stage 05-screenplay.
---

# 剧本深度融合与排版阶段

读取 `references/source.md` 作为方法来源。

输入可以是已确认的项目阶段文件，也可以是用户本轮明确指定为权威版本的现有剧本、大纲、角色卡、世界观或分场文件。修订模式允许直接读取现有剧本，不强迫重跑前序。

输出仅限：`02_script/screenplay.md`。

禁止：未经用户授权顺便重写其他阶段；禁止生成图像、表演和视频提示词。用户明确要求修订剧本时，应保留旧版本并只改指定范围。

完成后标记“待人工确认”，并停止。
