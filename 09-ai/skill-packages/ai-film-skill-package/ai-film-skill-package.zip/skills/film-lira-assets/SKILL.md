---
name: film-lira-assets
description: Generate production-ready image prompts and asset briefs from a final screenplay or user-supplied character, location, and prop materials when the router selects stage 06-assets.
---

# 图像资产阶段

读取 `references/source.md` 作为方法来源。

输入可以是 `02_script/screenplay.md`，也可以是用户本轮明确指定的最终剧本、角色卡、场景资料、道具资料或参考图。允许从 Lira 直接开始，不要求前序阶段全部存在。

输出仅限：`03_assets/assets-v01.md`。文件内按“角色 / 场景 / 道具”分组，并列出每条资产的 ID、参考依据与中文生成提示词。

禁止：未经用户授权改写剧本、重设角色弧光、输出表演段落或完整 Seedance 视频提示词。发现剧本问题时停止并建议总控切回剧本阶段，不在资产文件中偷偷修剧本。

完成后标记资产版本和“待人工确认”，并停止。
