---
name: film-synopsis
description: Create or revise only an AI film synopsis and concept anchor. Use only when the project router selects stage 01-synopsis.
---

# 故事概念阶段

读取 `references/source.md` 作为方法来源。

输入仅限：`00_project/brief.md` 与用户明确提出的故事要求。

输出仅限：`01_story/synopsis.md`。

禁止：生成角色圣经、世界观、分场、剧本、图像提示词、表演或视频提示词；禁止假设下游资产。

完成后在文件顶部写明“待人工确认”，并停止。
