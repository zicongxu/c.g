---
name: film-treatment
description: Transform approved story materials into a scene-by-scene treatment only. Use only when the project router selects stage 04-treatment.
---

# 分场大纲阶段

读取 `references/source.md` 作为方法来源。

输入仅限：`01_story/synopsis.md`、`01_story/characters.md`，以及已确认存在时的 `01_story/worldbuilding.md`。

输出仅限：`01_story/treatment.md`。

禁止：编写完整对白剧本、图像提示词、表演区块或视频提示词；不得改写上游文件。

完成后标记“待人工确认”，并停止。
