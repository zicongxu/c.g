---
name: film-worldbuilding
description: Create or revise only world rules, locations, factions, and story objects. Use only when the project router selects stage 03-worldbuilding.
---

# 世界观阶段

读取 `references/source.md` 作为方法来源。

输入仅限：`01_story/synopsis.md`、`01_story/characters.md`。

输出仅限：`01_story/worldbuilding.md`。

禁止：改写已确认的大纲和角色圣经；禁止生成分场、剧本、图像和视频提示词。

完成后标记“待人工确认”，并停止。
