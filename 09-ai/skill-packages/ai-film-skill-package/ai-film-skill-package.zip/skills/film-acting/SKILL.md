---
name: film-acting
description: Write only the acting and performance block for a user-approved scene or shot from project files or uploaded materials when the router selects stage 07-acting.
---

# 表演阶段

读取 `references/source.md` 作为方法来源。

输入可以是项目角色、剧本和资产文件，也可以是用户本轮明确指定的场景、镜头、角色卡、资产参考或表演目标。允许直接进入 ACTING，不要求全流程前序齐全。

输出仅限：`04_performance/acting-v01.md`。文件内按场景 ID 输出表演目标、阻力、策略、节拍变化、潜台词和可执行行为。

禁止：输出摄影机、光学镜头、完整 Seedance 提示词、图像提示词；不得未经用户授权重写剧本和角色圣经。发现上游问题时交回总控切换阶段。

完成后标记“待人工确认”，并停止。
