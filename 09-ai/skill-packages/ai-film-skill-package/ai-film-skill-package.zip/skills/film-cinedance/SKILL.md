---
name: film-cinedance
description: Write one production-ready CINEDANCE or Seedance video prompt from the current shot and any user-supplied asset, character, or performance references when the router selects stage 08-cinedance.
---

# Seedance 镜头导演阶段

读取 `references/source.md` 作为方法来源。

输入可以来自项目文件，也可以来自用户本轮上传并明确指定的镜头描述、角色卡、资产图、场景图、道具图、表演说明或必要剧本片段。允许只做 CINEDANCE，不要求 01 至 07 全部跑完。

输出仅限：`06_prompts/cinedance-v01.md`。文件内按镜头 ID 输出最终可复制的 CINEDANCE / Seedance 视频提示词。

禁止：未经用户授权改写故事、角色、世界观、分场或剧本；禁止输出未指定的其他镜头；禁止自动调用生成平台或修改上游资产。缺少非关键资料时不补造整套上游，只说明假设或询问最小必要信息。

## 动作与对白时间轴输出规则

- 时间轴必须根据当前镜头的剧情节拍设计，不设默认段长，也不得机械等分。
- 先结合镜头总时长，评估每个已确认动作的真实完成时间、对白实际说完所需时间、必要停顿与反应、摄影机运动和明确剪切点，再决定每段起止时间。各段可以长短不同，但必须首尾连续并覆盖完整镜头。
- 统一使用阿拉伯数字时间码 `起始时间 至 结束时间：内容`。只有剧情动作、对白口型或剪切节点确实需要精确控制时才使用小数秒；不得为了显得精细而把完整动作机械拆碎。
- 时间轴只负责安排用户已确认的镜头内容，不得为了填满时间段新增、改写或压缩剧情、对白、屏幕文字、角色反应、道具状态或剪辑事件。

完成后写明镜头 ID、引用资产版本、表演文件和“待人工确认”，并停止。
