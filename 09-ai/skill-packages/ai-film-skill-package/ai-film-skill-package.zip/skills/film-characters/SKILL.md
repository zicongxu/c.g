---
name: film-characters
description: Create or revise only the character bible for an approved synopsis. Use only when the project router selects stage 02-characters.
---

# 角色圣经阶段

读取 `references/source.md` 作为方法来源。

输入仅限：`01_story/synopsis.md`。

输出仅限：`01_story/characters.md`。

禁止：改写故事大纲、生成世界观、分场、剧本、图像提示词、表演或视频提示词。

完成后标记“待人工确认”，并停止。
