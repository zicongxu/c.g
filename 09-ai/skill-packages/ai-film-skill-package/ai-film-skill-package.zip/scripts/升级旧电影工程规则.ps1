param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectPath
)

$ErrorActionPreference = "Stop"

$resolvedProjectPath = (Resolve-Path -LiteralPath $ProjectPath).Path
$projectControlPath = Join-Path $resolvedProjectPath "00_project"
$templatePath = Join-Path $PSScriptRoot "..\project-template"
$templateRoutingPath = Join-Path $templatePath "00_project\routing.md"
$templateAgentsPath = Join-Path $templatePath "AGENTS.md"

if (-not (Test-Path -LiteralPath $projectControlPath)) {
    throw "这不是电影项目文件夹，缺少：$projectControlPath"
}

foreach ($requiredFile in @($templateAgentsPath, $templateRoutingPath)) {
    if (-not (Test-Path -LiteralPath $requiredFile)) {
        throw "安装包缺少规则模板：$requiredFile"
    }
}

$backupPath = Join-Path $projectControlPath ("rule-backup-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
New-Item -ItemType Directory -Path $backupPath -Force | Out-Null

$projectAgentsPath = Join-Path $resolvedProjectPath "AGENTS.md"
$projectRoutingPath = Join-Path $projectControlPath "routing.md"

foreach ($existingFile in @($projectAgentsPath, $projectRoutingPath)) {
    if (Test-Path -LiteralPath $existingFile) {
        Copy-Item -LiteralPath $existingFile -Destination $backupPath -Force
    }
}

Copy-Item -LiteralPath $templateAgentsPath -Destination $projectAgentsPath -Force
Copy-Item -LiteralPath $templateRoutingPath -Destination $projectRoutingPath -Force

$logPath = Join-Path $projectControlPath "rule-upgrade-log.md"
@"
# 规则升级记录

升级时间：$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
升级内容：项目总控规则与路由规则
已备份：$backupPath
未修改：故事、角色、剧本、资产、表演、镜头、提示词和历史版本
"@ | Set-Content -LiteralPath $logPath -Encoding utf8

Write-Output "旧电影工程规则升级完成：$resolvedProjectPath"
Write-Output "规则备份位置：$backupPath"
Write-Output "已更新：AGENTS.md、00_project\routing.md"
Write-Output "未修改：所有创作成果与项目历史"
